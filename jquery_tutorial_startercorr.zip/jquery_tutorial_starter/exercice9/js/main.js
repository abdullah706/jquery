$('button').click(function(){
    $('#text').css('display', 'block');
});