$('button').click(function(){
    $('#text').animate({
        'font-size': '+=34px'
    }, 3000);
});