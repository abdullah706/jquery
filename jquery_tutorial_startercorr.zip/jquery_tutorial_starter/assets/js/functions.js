function displaySecretText() {
    $('#exercise #text').show();
}