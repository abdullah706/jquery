$('button').click(function(){
    $('input').attr('disabled', false);
});