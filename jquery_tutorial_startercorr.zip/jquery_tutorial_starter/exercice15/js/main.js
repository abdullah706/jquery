$('button').click(function(){
    $('#text').addClass('float-right');
});