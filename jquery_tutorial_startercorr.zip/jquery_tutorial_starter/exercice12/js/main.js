$('button').click(function(){
    $('#square').css('width', '500px');
});