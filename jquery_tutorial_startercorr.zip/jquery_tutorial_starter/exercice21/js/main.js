$('button').click(function(){
    $('#square').animate({
        width: '+=400px'
    }, 3000);
});