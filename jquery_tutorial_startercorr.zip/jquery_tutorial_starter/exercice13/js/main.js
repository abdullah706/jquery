$('button').click(function(){
    $('#text').css('font-size', '50px');
});