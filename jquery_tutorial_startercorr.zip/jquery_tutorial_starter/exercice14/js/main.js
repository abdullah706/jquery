$('button').click(function(){
    $('#text').attr('class', 'float-right');
});