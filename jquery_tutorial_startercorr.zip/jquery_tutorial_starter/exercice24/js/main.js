$('button').click(function(){
    $('#bg').animate({
        'margin-left': '+=100px'
    }, 3000);
});