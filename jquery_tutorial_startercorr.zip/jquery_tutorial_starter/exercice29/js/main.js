$('button').click(function(){
    var text = $('input').val();
    var myClass = '';
    if (text.length < 5) {
        myClass = 'is-valid';
    } else {
        myClass = 'is-invalid';
    }
    $('input').addClass(myClass);
});