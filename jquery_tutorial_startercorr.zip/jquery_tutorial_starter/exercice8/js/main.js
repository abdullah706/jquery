function displaySecretText() {
    $('#text').css('display', 'block');
}

$('button').click(function(){
    displaySecretText();
});