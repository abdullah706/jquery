$('button').click(function(){
    console.log($('input').val());
});