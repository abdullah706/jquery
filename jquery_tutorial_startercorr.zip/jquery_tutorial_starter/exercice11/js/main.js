$('button').click(function(){
    $('#square').css('background-color', 'red');
});