$('button').click(function(){
    $('#text').show();
});