$('button').click(function(){
    $('#text').hide();
});