$('button').click(function(){
    $('input').addClass('is-valid');
});