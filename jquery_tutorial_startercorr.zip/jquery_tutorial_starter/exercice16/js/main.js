$('button').click(function(){
    $('#text').html('Konexio!');
});